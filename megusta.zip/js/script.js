var a =9;

function like1(){
    a++;
    console.log(a);
    var elemnt = document.querySelector("#l1");
    elemnt.innerText = a;
}

var b =12;

function like2(){
    b++;
    console.log(b);
    var elemnt = document.querySelector("#l2");
    elemnt.innerText = b;
}

var c =9;

function like3(){
    c++;
    console.log(c);
    var elemnt = document.querySelector("#l3");
    elemnt.innerText = c;

}